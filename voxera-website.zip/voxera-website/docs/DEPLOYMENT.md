# Putting Voxera online (free hosting)

This guide takes you from the project files to a live website, one step at a time.
You do not need to be technical. You will click through four websites and copy-paste a few items.

**Golden rules**

- **Never paste a key or password into a chat, an email, or a file in GitHub.** Copy it straight from the website that shows it into the website that needs it.
- If a key is ever exposed by accident, create a new one in the same dashboard and delete the old one ("rotate" it).
- Nothing here is irreversible until Step 7. Cloudflare keeps every version, and you can roll back.

## What you will use, and what it costs

| Service     | Used for                 | Cost                                      |
| ----------- | ------------------------ | ----------------------------------------- |
| GitHub      | Stores the project files | Free                                      |
| Cloudflare  | Hosts the website        | Free plan                                 |
| Supabase    | Stores enquiries         | Free plan                                 |
| Resend      | Sends the emails         | Free plan                                 |
| Your domain | The web address          | You already own it; renewals are not free |

### Free-plan limits (checked November 2026. Confirm on each pricing page)

- **Cloudflare Workers Free:** 100,000 dynamic requests per day and 10 ms of CPU time per request. Static files (images, scripts, styles) are free and unlimited.
- **Resend Free:** 3,000 emails a month and **100 a day**. Each enquiry sends 2 emails, so about 50 enquiries a day. The site refuses more than 40 enquiries a day to stay inside this.
- **Supabase Free:** 500 MB database, **projects pause after 1 week of inactivity**, and there are **no automatic backups**.

Nothing here switches to a paid plan by itself. If a limit is reached, the service stops or throttles instead of charging you. (Resend and Supabase pause; Cloudflare returns errors.) See "Keeping it free and healthy" at the end.

---

## Step 1: Put the project on GitHub

1. Create a free account at <https://github.com> if you do not have one.
2. Click **+** (top right) → **New repository**. Name it `voxera-website`. Choose **Private**. Click **Create repository**.
3. On the new empty repository page, click **uploading an existing file**.
4. Unzip the project on your computer. Open the unzipped folder and select **everything inside it** (not the folder itself) and drag it into the GitHub page. Make sure hidden files such as `.gitignore`, `.env.example` and `.node-version` are included (on Windows: View → Show → Hidden items; on Mac press Cmd+Shift+.).
5. Scroll down and click **Commit changes**.

Check: the repository shows folders `src`, `supabase`, `docs`, `public` and files such as `package.json` and `wrangler.jsonc`. There must be **no file named `.env`**.

## Step 2: Supabase (the database)

### 2a. Find out whether the existing project is yours

1. Sign in at <https://supabase.com/dashboard>.
2. If you see a project there, open it. In **Project Settings → API** the **Project URL** should match the `SUPABASE_URL` that was in your old Lovable `.env` file. If it matches, this is your project. Continue to 2b.
3. If you do **not** see it, the database was created and managed by Lovable. In that case:
   1. In Lovable, open the project's database and **export the existing enquiries as CSV** (keep this file safe).
   2. In Supabase click **New project** (free plan) and note the database password somewhere safe.
   3. Open **SQL Editor → New query**, paste the whole contents of `drizzle/migrations/0000_migration.sql` and click **Run**. This creates the enquiries table.
   4. Continue to 2b with this new project.

### 2b. Add the new columns

1. In Supabase open **SQL Editor → New query**.
2. Open `supabase/migrations/20261113000000_enquiry_tracking.sql` (on GitHub, click the file, then the copy icon), paste it in, and click **Run**.
3. It should say "Success". It only adds columns; no existing data is touched.

### 2c. Note two items (do not paste them anywhere yet)

- **Project URL**: Project Settings → API (looks like `https://abcd….supabase.co`).
- **Secret key** ("service_role" or "secret" key): Project Settings → API Keys. Keep this tab open. You will copy it straight into Cloudflare in Step 4. Never share it.

## Step 3: Resend (the emails)

1. Create a free account at <https://resend.com>.
2. Go to **Domains → Add Domain** and enter your website domain. Resend shows a few DNS records.
3. Add those records where your domain's DNS is managed (your registrar, or Cloudflare DNS if your domain is on Cloudflare). Click **Verify** in Resend. This can take from minutes to a few hours.
4. Go to **API Keys → Create API key**. Give it "Sending access" only. Keep this tab open; you will copy the key straight into Cloudflare.
5. Decide the sender address, for example `Voxera <enquiries@yourdomain.com>`. It must use the verified domain.

> Until the domain is verified, the confirmation email to visitors will fail (the enquiry is still saved and the failure is recorded).

## Step 4: Cloudflare (the hosting)

1. Create a free account at <https://dash.cloudflare.com>.
2. Go to **Workers & Pages → Create → Import a repository** (GitHub). Authorise Cloudflare and select only the `voxera-website` repository.
3. Settings to enter:
   - **Build command:** `bun run build`
   - **Deploy command:** `npx wrangler deploy` (the default)
   - **Build variables:** add `VITE_SITE_URL` = your final website address, e.g. `https://yourdomain.com` (no trailing slash).
4. Click **Save and Deploy**. Wait for the build to finish.
5. Open the Worker → **Settings → Variables and Secrets** and add these (choose **Secret** for the secret ones, **Text** otherwise):

   | Name                        | Type   | Value                                              |
   | --------------------------- | ------ | -------------------------------------------------- |
   | `SUPABASE_URL`              | Text   | Project URL from Step 2c                           |
   | `SUPABASE_SERVICE_ROLE_KEY` | Secret | Secret key from Step 2c                            |
   | `RESEND_API_KEY`            | Secret | API key from Step 3                                |
   | `EMAIL_FROM`                | Text   | e.g. `Voxera <enquiries@yourdomain.com>`           |
   | `NOTIFY_EMAIL_TO`           | Text   | `firas.zitouni@voxera.sbs` (or the inbox you want) |
   | `IP_HASH_SALT`              | Secret | Any long random text you make up                   |

6. Save and deploy when prompted.
7. Open the `…workers.dev` address Cloudflare shows. You should see the Voxera website.

> If the build fails with a message about `bun`, tell me the exact message from the build log and we will adjust the build command.

## Step 5: Test before using your own domain

On the `workers.dev` address:

1. Open the site on your phone and on a computer. Open the menu on the phone and visit every page.
2. Submit a **test enquiry** using your own email address. You should see the thank-you message.
3. Check all three:
   - The enquiry appears in Supabase (**Table Editor → quote_requests**) with `email_status = sent`.
   - The notification arrived at the Voxera inbox with all details.
   - The confirmation arrived at your test address.
4. Visit `/sitemap.xml` and `/robots.txt` on the site; both should show text.

Do not continue until all of these work.

## Step 6: Connect your own domain

1. In Cloudflare, your domain must be added as a "site" (free) and its nameservers pointed to Cloudflare. Cloudflare walks you through this under **Add a domain**; the nameserver change is made at the place you bought the domain.
2. Open the Worker → **Settings → Domains & Routes → Add → Custom domain**, and enter your domain (and `www.` if you want it).
3. Wait until it shows as active, then open your domain in a browser.
4. Confirm `VITE_SITE_URL` (Step 4) matches the real address; if you change it, trigger a new deployment (**Deployments → Retry** or push any change).

## Step 7: Final hardening (only after the live form works)

1. In Supabase **SQL Editor**, run `supabase/optional/lock_down_anonymous_insert.sql`. This removes unneeded public write access.
2. Submit one more test enquiry to confirm the form still works.
3. If it does not, tell me. The file explains how to undo the change.

---

## Keeping it free and healthy

- **Supabase pauses a free project after a week with no activity.** A paused project cannot save enquiries; the form then shows an error asking visitors to email you. Check the Supabase dashboard about once a week and click **Restore** if it is paused, or ask me to add an automatic keep-alive, or move to the paid plan (about $25/month).
- **There are no automatic backups on Supabase Free.** Once a month, open **Table Editor → quote_requests → Export** and save the CSV.
- **Resend's daily limit** (100 emails). If it is ever hit, enquiries are still saved; only the emails fail, and the row says `email_status = failed`. Check the table for failed rows now and then.
- **Cloudflare's 10 ms CPU limit.** The pages are rendered on demand. I could not measure real CPU time outside Cloudflare, only that requests complete in roughly 7 to 15 ms locally. If you ever see "Error 1102" or "Worker exceeded resource limits" on the live site, tell me. Fixes: pre-build the pages as static files (I can do this), or the Workers Paid plan ($5/month).
- **Your domain** renews yearly with your registrar.
- **Roll back a bad update:** Cloudflare → your Worker → **Deployments**, choose the previous version, **Rollback**.

## Updating the site later

Edit the files on GitHub (or push from a computer). Cloudflare rebuilds and deploys automatically in a couple of minutes.
Business email, privacy-policy date and similar details live in `src/lib/site.ts`.
