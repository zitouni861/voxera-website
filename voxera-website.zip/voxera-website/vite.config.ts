import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import { nitro } from "nitro/vite";

// Plain Vite configuration for TanStack Start, deployed as a Cloudflare Worker via Nitro.
export default defineConfig(({ command, mode }) => {
  // Local development only: make .env / .env.local visible to server functions as process.env,
  // the way Cloudflare exposes secrets in production. Real environment variables always win.
  if (command === "serve") {
    for (const [key, value] of Object.entries(loadEnv(mode, process.cwd(), ""))) {
      if (process.env[key] === undefined) process.env[key] = value;
    }
  }

  return {
    resolve: {
      tsconfigPaths: true, // resolves the "@/..." imports from tsconfig.json
      dedupe: ["react", "react-dom", "@tanstack/react-router", "@tanstack/react-start"],
    },
    server: { port: 8080 },
    plugins: [
      tailwindcss(),
      // Use src/server.ts (our error handling and security headers) as the server entry.
      tanstackStart({ server: { entry: "server" } }),
      // Production build output is a Cloudflare Worker. Skipped for the dev server.
      ...(command === "build" ? [nitro({ preset: "cloudflare-module" })] : []),
      react(),
    ],
  };
});
