# Voxera website

Marketing website for Voxera, an Arabic ↔ English remote interpreting service (phone and video).
It has five public pages, a privacy policy, and an enquiry form that saves every enquiry to a
database and emails a notification.

- **Pages:** Home, Services, Industries, Why Voxera, Contact (enquiry form), Privacy Policy
- **Stack:** TanStack Start (React 19, server-side rendering), Vite, Tailwind CSS v4, Zod
- **Hosting target:** Cloudflare Workers (built with Nitro)
- **Database:** Supabase (Postgres), **Email:** Resend

> **Ready to put it online?** Follow [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md). It assumes no technical background.

## How the enquiry form works

1. The browser checks the form, then sends it to a server function.
2. The server checks everything again (the browser is never trusted), applies spam checks
   (hidden trap field, minimum fill time, rate limits), and **saves the enquiry first**.
3. Only then does it email the Voxera inbox and send a confirmation to the visitor.
4. If an email fails, the enquiry is still saved and flagged (`email_status = 'failed'` in the
   database). A lead is never lost because of an email problem.

The Supabase service key and the Resend key exist only on the server. They are never sent to browsers.

## Run it on your computer

You need [Node.js 22+](https://nodejs.org) and [Bun](https://bun.sh).

```bash
bun install
cp .env.example .env.local     # then fill in the values (never commit this file)
bun run dev                    # http://localhost:8080
```

The pages work without any settings. The enquiry form needs the Supabase and Resend values.

## Commands

| Command                | What it does                                                                                         |
| ---------------------- | ---------------------------------------------------------------------------------------------------- |
| `bun run dev`          | Start the development server                                                                         |
| `bun run build`        | Build the production Cloudflare Worker into `.output/`                                               |
| `bun run preview`      | Run the built Worker locally in Cloudflare's runtime (run `build` first; settings go in `.dev.vars`) |
| `bun run test`         | Run the automated tests                                                                              |
| `bun run typecheck`    | TypeScript check                                                                                     |
| `bun run lint`         | Lint                                                                                                 |
| `bun run format:check` | Check formatting (`bun run format` fixes it)                                                         |
| `bun run audit`        | Check dependencies for known vulnerabilities                                                         |
| `bun run deploy`       | Build and deploy to Cloudflare (needs a logged-in Wrangler)                                          |

## Settings (environment variables)

See [`.env.example`](.env.example). Locally they go in `.env.local`; in production they are set
in the Cloudflare dashboard (never in a file in the repo).

| Name                        | Where  | Purpose                                                        |
| --------------------------- | ------ | -------------------------------------------------------------- |
| `SUPABASE_URL`              | server | Your Supabase project URL                                      |
| `SUPABASE_SERVICE_ROLE_KEY` | server | **Secret.** Lets the server save enquiries                     |
| `RESEND_API_KEY`            | server | **Secret.** Sends email                                        |
| `EMAIL_FROM`                | server | Sender, e.g. `Voxera <enquiries@yourdomain>` (verified domain) |
| `NOTIFY_EMAIL_TO`           | server | Inbox that receives new enquiries                              |
| `IP_HASH_SALT`              | server | Optional random string for the spam rate limiter               |
| `VITE_SITE_URL`             | build  | Public site address, used for canonical links and the sitemap  |

## Database

SQL files are in `supabase/`:

- `drizzle/migrations/0000_migration.sql` is the original `quote_requests` table (kept for reference; already applied to the existing project).
- `supabase/migrations/20261113000000_enquiry_tracking.sql` adds columns for consent, email status and rate limiting. It only **adds** columns and is safe to run more than once. Run it **before** deploying.
- `supabase/optional/lock_down_anonymous_insert.sql` removes unneeded public write access. Run it **only after** the live form has been tested.

## Project layout

```
src/routes/          Pages (file-based routing) + sitemap.xml and robots.txt
src/components/site/ Header (with mobile menu), footer, page hero
src/lib/             Form schema, spam/rate-limit + save pipeline, email templates, SEO helper
src/integrations/    Supabase server client and database types
src/server.ts        Server entry: error handling and security headers
wrangler.jsonc       Cloudflare Worker settings (name, runtime version)
vite.config.ts       Build configuration
supabase/            Database SQL
docs/                Deployment guide
```

## Things to know

- **Edit contact details** in `src/lib/site.ts` (business email, privacy-policy date).
- **Privacy policy** is written for what the site actually does. Have someone qualified review it for your location before relying on it.
- **Fonts** are loaded from Google Fonts. The privacy policy says so. Self-hosting them would remove that third party.
- **Remaining audit notes:** `bun audit` reports `picomatch` (high) and `minimatch` (moderate). Both live in build and lint tooling, not in code that handles visitors, and `picomatch` has no patched release yet. Re-run `bun audit` from time to time.
