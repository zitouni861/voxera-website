import { z } from "zod";

// Shared by the browser form and the server so both apply identical rules.
export const INDUSTRIES = [
  "Healthcare",
  "Insurance",
  "Public services",
  "Language service provider",
  "Other organisation",
] as const;
export const SERVICES = [
  "Over-the-Phone Interpretation (OPI)",
  "Video Remote Interpretation (VRI)",
  "Both OPI and VRI",
] as const;
export const MONTHLY_HOURS = [
  "Under 10 hours",
  "10–49 hours",
  "50–199 hours",
  "200 or more hours",
] as const;

// eslint-disable-next-line no-control-regex
const ANY_CONTROL = /[\u0000-\u001F\u007F]/;
// eslint-disable-next-line no-control-regex
const CONTROL_EXCEPT_NEWLINE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/;

function text(max: number, opts: { required?: string; multiline?: boolean } = {}) {
  let s = z.string().trim();
  if (opts.required) s = s.min(1, opts.required);
  const bad = opts.multiline ? CONTROL_EXCEPT_NEWLINE : ANY_CONTROL;
  return s.max(max).refine((v) => !bad.test(v), "Contains invalid characters");
}

export const quoteSchema = z.object({
  full_name: text(120, { required: "Please enter your name" }),
  email: z
    .string()
    .trim()
    .min(1, "Please enter a valid email")
    .max(255)
    .email("Please enter a valid email")
    .refine((v) => !ANY_CONTROL.test(v), "Please enter a valid email"),
  company: text(160, { required: "Please enter your company" }),
  job_title: text(120).optional().default(""),
  country: text(80).optional().default(""),
  industry: z.enum(INDUSTRIES, { message: "Please choose an industry" }),
  service: z.enum(SERVICES, { message: "Please choose a service" }),
  monthly_hours: z
    .union([z.enum(MONTHLY_HOURS), z.literal("")])
    .optional()
    .default(""),
  requirements: text(2000, { multiline: true }).optional().default(""),
  additional_info: text(2000, { multiline: true }).optional().default(""),
  consent: z.boolean().refine((v) => v === true, "Please confirm you have read the privacy policy"),
  // Spam traps: "extra_details" is a hidden field humans never fill in; elapsed_ms is time spent on the form.
  extra_details: z.string().max(500).optional().default(""),
  elapsed_ms: z.number().int().min(0).max(86_400_000).optional().default(0),
});

export type QuoteInput = z.input<typeof quoteSchema>;
export type QuoteData = z.output<typeof quoteSchema>;

export type QuoteResult =
  | { ok: true; id: string | null; notified: boolean; confirmationSent: boolean }
  | {
      ok: false;
      code: "invalid" | "too_fast" | "rate_limited" | "save_failed";
      message: string;
      fieldErrors?: Record<string, string>;
    };
