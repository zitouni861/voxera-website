import type { EmailMessage } from "./quote-email";

type ResendConfig = {
  apiKey: string | undefined;
  from: string | undefined;
  apiUrl?: string | undefined;
};

// Sends one email through Resend's REST API. Throws on any failure so the caller can record it.
export async function sendViaResend(msg: EmailMessage, cfg: ResendConfig): Promise<void> {
  if (!cfg.apiKey || !cfg.from)
    throw new Error("Email is not configured (RESEND_API_KEY / EMAIL_FROM)");
  const base = (cfg.apiUrl || "https://api.resend.com").replace(/\/+$/, "");
  const headers: Record<string, string> = {
    Authorization: `Bearer ${cfg.apiKey}`,
    "Content-Type": "application/json",
  };
  if (msg.idempotencyKey) headers["Idempotency-Key"] = msg.idempotencyKey;
  const res = await fetch(`${base}/emails`, {
    method: "POST",
    headers,
    signal: AbortSignal.timeout(10_000),
    body: JSON.stringify({
      from: cfg.from,
      to: [msg.to],
      subject: msg.subject,
      text: msg.text,
      html: msg.html,
      ...(msg.replyTo ? { reply_to: msg.replyTo } : {}),
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`Resend responded ${res.status}: ${body.slice(0, 300)}`);
  }
}
