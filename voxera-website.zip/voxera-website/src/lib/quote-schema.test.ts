import { describe, expect, it } from "vitest";
import { quoteSchema } from "./quote-schema";

const valid = {
  full_name: "Amira Test",
  email: "amira@example.org",
  company: "Example Health",
  industry: "Healthcare",
  service: "Both OPI and VRI",
  consent: true,
  elapsed_ms: 9000,
};

describe("quoteSchema", () => {
  it("accepts a minimal valid enquiry and fills optional defaults", () => {
    const r = quoteSchema.safeParse(valid);
    expect(r.success).toBe(true);
    if (r.success) {
      expect(r.data.job_title).toBe("");
      expect(r.data.monthly_hours).toBe("");
      expect(r.data.extra_details).toBe("");
    }
  });

  it("trims whitespace", () => {
    const r = quoteSchema.parse({ ...valid, full_name: "  Amira  " });
    expect(r.full_name).toBe("Amira");
  });

  it.each([
    ["full_name", ""],
    ["company", "   "],
    ["email", "not-an-email"],
    ["email", "a@b"],
    ["industry", "Pirates"],
    ["service", ""],
  ])("rejects bad %s = %j", (key, value) => {
    expect(quoteSchema.safeParse({ ...valid, [key]: value }).success).toBe(false);
  });

  it("requires the privacy consent to be true", () => {
    expect(quoteSchema.safeParse({ ...valid, consent: false }).success).toBe(false);
    expect(quoteSchema.safeParse({ ...valid, consent: undefined }).success).toBe(false);
  });

  it("rejects line breaks in single-line fields but allows them in free text", () => {
    expect(quoteSchema.safeParse({ ...valid, full_name: "Evil\r\nBcc: x@y.z" }).success).toBe(
      false,
    );
    expect(quoteSchema.safeParse({ ...valid, company: "Acme\nCorp" }).success).toBe(false);
    expect(quoteSchema.safeParse({ ...valid, requirements: "Line one\nLine two" }).success).toBe(
      true,
    );
  });

  it("enforces length limits", () => {
    expect(quoteSchema.safeParse({ ...valid, full_name: "x".repeat(121) }).success).toBe(false);
    expect(quoteSchema.safeParse({ ...valid, requirements: "x".repeat(2001) }).success).toBe(false);
    expect(quoteSchema.safeParse({ ...valid, requirements: "x".repeat(2000) }).success).toBe(true);
  });

  it("accepts known monthly-hours values and the empty choice only", () => {
    expect(quoteSchema.safeParse({ ...valid, monthly_hours: "50–199 hours" }).success).toBe(true);
    expect(quoteSchema.safeParse({ ...valid, monthly_hours: "" }).success).toBe(true);
    expect(quoteSchema.safeParse({ ...valid, monthly_hours: "a million" }).success).toBe(false);
  });
});
