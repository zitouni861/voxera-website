import { SITE_NAME, SITE_URL } from "./site";

type SeoInput = { title: string; description: string; path: string; ogTitle?: string };

// Builds title, description, canonical link, Open Graph and Twitter tags for a page.
export function seo({ title, description, path, ogTitle }: SeoInput) {
  const url = `${SITE_URL}${path === "/" ? "/" : path}`;
  const image = `${SITE_URL}/og-image.png`;
  const shareTitle = ogTitle ?? title;
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:site_name", content: SITE_NAME },
      { property: "og:title", content: shareTitle },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { property: "og:url", content: url },
      { property: "og:image", content: image },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:image:alt", content: "Voxera: Arabic-English remote interpreting" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: shareTitle },
      { name: "twitter:description", content: description },
      { name: "twitter:image", content: image },
    ],
    links: [{ rel: "canonical", href: url }],
  };
}
