import { describe, expect, it } from "vitest";
import { buildConfirmation, buildNotification, escapeHtml } from "./quote-email";
import type { QuoteData } from "./quote-schema";

const base: QuoteData = {
  full_name: "Amira Test",
  email: "amira@example.org",
  company: "Example Health",
  job_title: "",
  country: "Tunisia",
  industry: "Healthcare",
  service: "Both OPI and VRI",
  monthly_hours: "",
  requirements: "",
  additional_info: "",
  consent: true,
  extra_details: "",
  elapsed_ms: 9000,
};
const meta = {
  id: "abc",
  createdAt: new Date("2026-11-17T10:00:00Z"),
  to: "owner@example.com",
  siteName: "Voxera",
};

describe("email builders", () => {
  it("escapes HTML in every user-supplied value", () => {
    const evil = `<script>alert(1)</script> & "quotes"`;
    const n = buildNotification(
      { ...base, full_name: evil, company: evil, requirements: evil, additional_info: evil },
      meta,
    );
    expect(n.html).not.toContain("<script>");
    expect(n.html).toContain("&lt;script&gt;");
    const c = buildConfirmation(
      { ...base, full_name: evil, company: evil },
      { ...meta, replyTo: "owner@example.com" },
    );
    expect(c.html).not.toContain("<script>");
  });

  it("keeps subject lines on one line even if a value contains line breaks", () => {
    const n = buildNotification({ ...base, company: "Acme\r\nBcc: attacker@example.com" }, meta);
    expect(n.subject).not.toMatch(/[\r\n]/);
  });

  it("labels empty optional fields clearly", () => {
    const n = buildNotification(base, meta);
    expect(n.text).toContain("Job title: Not provided");
    expect(n.text).toContain("Estimated monthly hours: Not provided");
  });

  it("sends the confirmation to the enquirer, with replies going to the business", () => {
    const c = buildConfirmation(base, { ...meta, replyTo: "owner@example.com" });
    expect(c.to).toBe("amira@example.org");
    expect(c.replyTo).toBe("owner@example.com");
    expect(c.subject).toContain("Voxera");
  });

  it("uses distinct idempotency keys so retries cannot duplicate or collide", () => {
    const n = buildNotification(base, meta);
    const c = buildConfirmation(base, { ...meta, replyTo: "owner@example.com" });
    expect(n.idempotencyKey).toBe("abc-notify");
    expect(c.idempotencyKey).toBe("abc-confirm");
  });

  it("escapeHtml handles the five special characters", () => {
    expect(escapeHtml(`<>&"'`)).toBe("&lt;&gt;&amp;&quot;&#39;");
  });
});
