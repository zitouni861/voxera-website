// Server-only wiring: connects processQuote to Supabase, Resend and the incoming request.
import { getRequest } from "@tanstack/react-start/server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { sendViaResend } from "./email.server";
import { hashIp, processQuote, type QuoteDeps } from "./quote.server";
import { CONTACT_EMAIL, PRIVACY_VERSION, SITE_NAME } from "./site";

const env = (key: string): string | undefined => process.env[key] || undefined;

export async function handleQuote(input: unknown) {
  const req = getRequest();
  const ip =
    req?.headers.get("cf-connecting-ip") ??
    req?.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    null;
  const salt = env("IP_HASH_SALT") ?? env("SUPABASE_SERVICE_ROLE_KEY") ?? "voxera";

  const deps: QuoteDeps = {
    now: () => new Date(),
    ip,
    hashIp: (value) => hashIp(value, salt),
    insert: async (row) => {
      const { data, error } = await supabaseAdmin
        .from("quote_requests")
        .insert(row)
        .select("id")
        .single();
      if (error || !data) throw new Error(error?.message ?? "Insert returned no row");
      return { id: data.id };
    },
    countSince: async (sinceIso, ipHash) => {
      let q = supabaseAdmin
        .from("quote_requests")
        .select("id", { count: "exact", head: true })
        .gte("created_at", sinceIso);
      if (ipHash) q = q.eq("ip_hash", ipHash);
      const { count, error } = await q;
      if (error) throw new Error(error.message);
      return count ?? 0;
    },
    updateStatus: async (id, patch) => {
      const { error } = await supabaseAdmin.from("quote_requests").update(patch).eq("id", id);
      if (error) throw new Error(error.message);
    },
    sendEmail: (msg) =>
      sendViaResend(msg, {
        apiKey: env("RESEND_API_KEY"),
        from: env("EMAIL_FROM"),
        apiUrl: env("RESEND_API_URL"),
      }),
    notifyTo: env("NOTIFY_EMAIL_TO") ?? CONTACT_EMAIL,
    siteName: SITE_NAME,
    contactEmail: CONTACT_EMAIL,
    privacyVersion: PRIVACY_VERSION,
    // Never log enquiry contents or contact details, only event names and ids.
    log: (event, fields) => console.log(JSON.stringify({ event, ...fields })),
  };
  return processQuote(input, deps);
}
