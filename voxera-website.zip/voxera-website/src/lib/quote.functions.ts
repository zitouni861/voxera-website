import { createServerFn } from "@tanstack/react-start";
import type { QuoteInput, QuoteResult } from "./quote-schema";

// Validation, spam checks, saving and email all happen on the server (see quote.server.ts).
// The server module is imported inside the handler so it never reaches the browser bundle.
export const submitQuote = createServerFn({ method: "POST" })
  .inputValidator((input: QuoteInput) => input)
  .handler(async ({ data }): Promise<QuoteResult> => {
    const { handleQuote } = await import("./quote.runtime.server");
    return handleQuote(data);
  });
