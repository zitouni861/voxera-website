// Central site settings. VITE_SITE_URL is set at build time (see .env.example).
export const SITE_NAME = "Voxera";
export const SITE_URL = (import.meta.env["VITE_SITE_URL"] ?? "https://voxera.sbs").replace(
  /\/+$/,
  "",
);
export const CONTACT_EMAIL = "firas.zitouni@voxera.sbs";
export const PRIVACY_VERSION = "2026-11-13";
