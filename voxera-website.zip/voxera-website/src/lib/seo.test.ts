import { describe, expect, it } from "vitest";
import { seo } from "./seo";
import { SITE_URL } from "./site";

describe("seo()", () => {
  const out = seo({ title: "Services | Voxera", description: "Desc", path: "/services" });
  const meta = (key: string) =>
    out.meta.find(
      (m) => ("name" in m && m.name === key) || ("property" in m && m.property === key),
    );

  it("sets an absolute canonical URL", () => {
    expect(out.links[0]).toEqual({ rel: "canonical", href: `${SITE_URL}/services` });
  });
  it("sets Open Graph and Twitter share tags with an absolute image", () => {
    expect(meta("og:url")).toMatchObject({ content: `${SITE_URL}/services` });
    expect(meta("og:image")).toMatchObject({ content: `${SITE_URL}/og-image.png` });
    expect(meta("twitter:card")).toMatchObject({ content: "summary_large_image" });
    expect(meta("description")).toMatchObject({ content: "Desc" });
  });
  it("uses the bare site URL for the home page", () => {
    expect(seo({ title: "t", description: "d", path: "/" }).links[0]?.href).toBe(`${SITE_URL}/`);
  });
});
