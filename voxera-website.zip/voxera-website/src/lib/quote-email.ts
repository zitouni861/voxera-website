import type { QuoteData } from "./quote-schema";

export type EmailMessage = {
  to: string;
  subject: string;
  text: string;
  html: string;
  replyTo?: string;
  idempotencyKey?: string;
};

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// Anything that goes into a subject line must be a single line.
// eslint-disable-next-line no-control-regex
const oneLine = (s: string) => s.replace(/[\u0000-\u001F\u007F]+/g, " ").trim();
const dash = (s: string) => (s === "" ? "Not provided" : s);

type Meta = { id: string; createdAt: Date; to: string; siteName: string };

export function buildNotification(d: QuoteData, m: Meta): EmailMessage {
  const rows: [string, string][] = [
    ["Name", d.full_name],
    ["Email", d.email],
    ["Company", d.company],
    ["Job title", dash(d.job_title)],
    ["Country", dash(d.country)],
    ["Industry", d.industry],
    ["Service required", d.service],
    ["Language pair", "Arabic ↔ English"],
    ["Estimated monthly hours", dash(d.monthly_hours)],
    ["Current requirements", dash(d.requirements)],
    ["Additional information", dash(d.additional_info)],
    ["Received (UTC)", m.createdAt.toISOString()],
    ["Reference", m.id],
  ];
  const text =
    `New ${m.siteName} enquiry\n\n` +
    rows.map(([k, v]) => `${k}: ${v}`).join("\n") +
    `\n\nReply to this email to respond directly to ${oneLine(d.full_name)}.\n`;
  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;color:#1d2b2e;max-width:640px">` +
    `<h2 style="margin:0 0 16px;color:#004e4e">New ${escapeHtml(m.siteName)} enquiry</h2>` +
    `<table style="border-collapse:collapse;width:100%">` +
    rows
      .map(
        ([k, v]) =>
          `<tr><td style="padding:8px 12px;border:1px solid #e3ddd0;background:#f6f1e6;font-weight:bold;vertical-align:top;white-space:nowrap">${escapeHtml(k)}</td>` +
          `<td style="padding:8px 12px;border:1px solid #e3ddd0;white-space:pre-wrap">${escapeHtml(v)}</td></tr>`,
      )
      .join("") +
    `</table><p style="color:#5b6b6e;font-size:13px">Reply to this email to respond directly to the sender.</p></div>`;
  return {
    to: m.to,
    subject: oneLine(`New enquiry: ${d.company} (${d.service})`).slice(0, 200),
    text,
    html,
    replyTo: d.email,
    idempotencyKey: `${m.id}-notify`,
  };
}

export function buildConfirmation(d: QuoteData, m: Meta & { replyTo: string }): EmailMessage {
  const name = oneLine(d.full_name);
  const text =
    `Dear ${name},\n\n` +
    `Thank you for contacting ${m.siteName}. We have received your enquiry about ${d.service} ` +
    `for ${d.company}, and the team will review your requirements and be in touch.\n\n` +
    `For your records, you told us:\n` +
    `- Industry: ${d.industry}\n- Service: ${d.service}\n- Language pair: Arabic ↔ English\n` +
    `- Estimated monthly hours: ${dash(d.monthly_hours)}\n\n` +
    `If you need to add anything, simply reply to this email.\n\n` +
    `Kind regards,\nThe ${m.siteName} team\n\n` +
    `You are receiving this because this email address was used to submit an enquiry on the ${m.siteName} website. ` +
    `If that was not you, you can ignore this message.\n`;
  const html =
    `<div style="font-family:Arial,Helvetica,sans-serif;color:#1d2b2e;max-width:560px;line-height:1.5">` +
    `<h2 style="color:#004e4e;margin:0 0 12px">Thank you for contacting ${escapeHtml(m.siteName)}</h2>` +
    `<p>Dear ${escapeHtml(name)},</p>` +
    `<p>We have received your enquiry about <strong>${escapeHtml(d.service)}</strong> for ${escapeHtml(d.company)}. ` +
    `The team will review your requirements and be in touch.</p>` +
    `<p style="margin-bottom:4px">For your records, you told us:</p><ul style="margin-top:0">` +
    `<li>Industry: ${escapeHtml(d.industry)}</li><li>Service: ${escapeHtml(d.service)}</li>` +
    `<li>Language pair: Arabic ↔ English</li><li>Estimated monthly hours: ${escapeHtml(dash(d.monthly_hours))}</li></ul>` +
    `<p>If you need to add anything, simply reply to this email.</p>` +
    `<p>Kind regards,<br>The ${escapeHtml(m.siteName)} team</p>` +
    `<p style="color:#5b6b6e;font-size:12px">You are receiving this because this email address was used to submit an enquiry on the ${escapeHtml(m.siteName)} website. If that was not you, you can ignore this message.</p></div>`;
  return {
    to: d.email,
    subject: `We received your enquiry – ${m.siteName}`,
    text,
    html,
    replyTo: m.replyTo,
    idempotencyKey: `${m.id}-confirm`,
  };
}
