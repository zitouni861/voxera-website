import { buildConfirmation, buildNotification, type EmailMessage } from "./quote-email";
import { quoteSchema, type QuoteResult } from "./quote-schema";

export const RATE_WINDOW_MS = 60 * 60 * 1000;
export const PER_IP_LIMIT = 5;
// Resend's free plan allows 100 emails/day and each enquiry sends 2, so cap at 40 enquiries/day.
export const DAY_MS = 24 * 60 * 60 * 1000;
export const GLOBAL_DAILY_LIMIT = 40;
export const MIN_ELAPSED_MS = 1500;

export type QuoteRow = {
  full_name: string;
  email: string;
  company: string;
  job_title: string | null;
  country: string | null;
  industry: string;
  service: string;
  monthly_hours: string | null;
  requirements: string | null;
  additional_info: string | null;
  consent_at: string;
  privacy_version: string;
  ip_hash: string | null;
  email_status: "pending";
};

export type StatusPatch = {
  email_status: "sent" | "failed";
  email_error: string | null;
  notified_at: string | null;
  confirmation_status: "sent" | "failed";
};

// Everything that touches the outside world is injected so the logic can be tested without it.
export type QuoteDeps = {
  now: () => Date;
  ip: string | null;
  hashIp: (ip: string) => Promise<string>;
  insert: (row: QuoteRow) => Promise<{ id: string }>;
  countSince: (sinceIso: string, ipHash: string | null) => Promise<number>;
  updateStatus: (id: string, patch: StatusPatch) => Promise<void>;
  sendEmail: (msg: EmailMessage) => Promise<void>;
  notifyTo: string;
  siteName: string;
  contactEmail: string;
  privacyVersion: string;
  log: (event: string, fields?: Record<string, unknown>) => void;
};

export async function hashIp(ip: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(`${salt}:${ip}`);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("")
    .slice(0, 32);
}

const orNull = (s: string) => (s === "" ? null : s);
const errText = (e: unknown) => (e instanceof Error ? e.message : String(e)).slice(0, 500);

export async function processQuote(input: unknown, deps: QuoteDeps): Promise<QuoteResult> {
  // 1. Validate again on the server: the browser is never trusted.
  const parsed = quoteSchema.safeParse(input);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[String(issue.path[0])] ??= issue.message;
    return {
      ok: false,
      code: "invalid",
      message: "Please check the highlighted fields.",
      fieldErrors,
    };
  }
  const d = parsed.data;

  // 2. Spam traps. A filled honeypot gets a fake success so bots learn nothing.
  if (d.extra_details !== "") {
    deps.log("spam_honeypot");
    return { ok: true, id: null, notified: false, confirmationSent: false };
  }
  if (d.elapsed_ms < MIN_ELAPSED_MS) {
    deps.log("spam_too_fast");
    return {
      ok: false,
      code: "too_fast",
      message: "That was very quick. Please check your details and submit again.",
    };
  }

  // 3. Rate limiting (per network address per hour, plus a global daily ceiling). Fails open if the check itself breaks.
  const now = deps.now();
  const sinceHour = new Date(now.getTime() - RATE_WINDOW_MS).toISOString();
  const sinceDay = new Date(now.getTime() - DAY_MS).toISOString();
  let ipHash: string | null = null;
  try {
    ipHash = deps.ip ? await deps.hashIp(deps.ip) : null;
    const [perIp, global] = await Promise.all([
      ipHash ? deps.countSince(sinceHour, ipHash) : Promise.resolve(0),
      deps.countSince(sinceDay, null),
    ]);
    if (perIp >= PER_IP_LIMIT || global >= GLOBAL_DAILY_LIMIT) {
      deps.log("rate_limited", { perIp, global });
      return {
        ok: false,
        code: "rate_limited",
        message: `We've received several enquiries recently. Please try again later, or email us at ${deps.contactEmail}.`,
      };
    }
  } catch (e) {
    deps.log("rate_check_failed", { error: errText(e) });
  }

  // 4. Save first. Nothing else matters if the lead isn't stored.
  let id: string;
  try {
    const row = await deps.insert({
      full_name: d.full_name,
      email: d.email,
      company: d.company,
      job_title: orNull(d.job_title),
      country: orNull(d.country),
      industry: d.industry,
      service: d.service,
      monthly_hours: orNull(d.monthly_hours),
      requirements: orNull(d.requirements),
      additional_info: orNull(d.additional_info),
      consent_at: now.toISOString(),
      privacy_version: deps.privacyVersion,
      ip_hash: ipHash,
      email_status: "pending",
    });
    id = row.id;
  } catch (e) {
    deps.log("save_failed", { error: errText(e) });
    return {
      ok: false,
      code: "save_failed",
      message: `We couldn't save your enquiry. Please try again, or email us at ${deps.contactEmail}.`,
    };
  }

  // 5. Emails. Failures are recorded on the saved row but never undo or hide the lead.
  const meta = { id, createdAt: now, to: deps.notifyTo, siteName: deps.siteName };
  const [notify, confirm] = await Promise.allSettled([
    deps.sendEmail(buildNotification(d, meta)),
    deps.sendEmail(buildConfirmation(d, { ...meta, replyTo: deps.notifyTo })),
  ]);
  const notified = notify.status === "fulfilled";
  const confirmationSent = confirm.status === "fulfilled";
  if (!notified) deps.log("notify_failed", { id, error: errText(notify.reason) });
  if (!confirmationSent) deps.log("confirmation_failed", { id, error: errText(confirm.reason) });

  try {
    await deps.updateStatus(id, {
      email_status: notified ? "sent" : "failed",
      email_error: notified ? null : errText((notify as PromiseRejectedResult).reason),
      notified_at: notified ? deps.now().toISOString() : null,
      confirmation_status: confirmationSent ? "sent" : "failed",
    });
  } catch (e) {
    deps.log("status_update_failed", { id, error: errText(e) });
  }

  deps.log("enquiry_saved", { id, notified, confirmationSent });
  return { ok: true, id, notified, confirmationSent };
}
