import { describe, expect, it } from "vitest";
import type { EmailMessage } from "./quote-email";
import {
  GLOBAL_DAILY_LIMIT,
  PER_IP_LIMIT,
  processQuote,
  type QuoteDeps,
  type QuoteRow,
  type StatusPatch,
} from "./quote.server";

const valid = {
  full_name: "Amira Test",
  email: "amira@example.org",
  company: "Example Health",
  country: "Tunisia",
  industry: "Healthcare",
  service: "Over-the-Phone Interpretation (OPI)",
  monthly_hours: "50–199 hours",
  requirements: "Daily clinic calls",
  consent: true,
  elapsed_ms: 9000,
};

function setup(over: Partial<QuoteDeps> = {}) {
  const order: string[] = [];
  const inserted: QuoteRow[] = [];
  const emails: EmailMessage[] = [];
  const updates: StatusPatch[] = [];
  const logs: string[] = [];
  const deps: QuoteDeps = {
    now: () => new Date("2026-11-17T10:00:00Z"),
    ip: "203.0.113.9",
    hashIp: async (ip) => `hash:${ip}`,
    insert: async (row) => {
      order.push("insert");
      inserted.push(row);
      return { id: "row-1" };
    },
    countSince: async () => 0,
    updateStatus: async (_id, patch) => {
      order.push("update");
      updates.push(patch);
    },
    sendEmail: async (m) => {
      order.push("email");
      emails.push(m);
    },
    notifyTo: "owner@example.com",
    siteName: "Voxera",
    contactEmail: "owner@example.com",
    privacyVersion: "v1",
    log: (e) => logs.push(e),
    ...over,
  };
  return { deps, order, inserted, emails, updates, logs };
}

describe("processQuote", () => {
  it("saves the enquiry, then emails the owner and the enquirer", async () => {
    const s = setup();
    const r = await processQuote(valid, s.deps);
    expect(r).toEqual({ ok: true, id: "row-1", notified: true, confirmationSent: true });
    expect(s.order[0]).toBe("insert"); // saved before any email
    expect(s.emails.map((e) => e.to).sort()).toEqual(["amira@example.org", "owner@example.com"]);
    expect(s.updates[0]).toMatchObject({
      email_status: "sent",
      confirmation_status: "sent",
      email_error: null,
    });
  });

  it("includes all key details in the owner notification, and replies go to the enquirer", async () => {
    const s = setup();
    await processQuote(valid, s.deps);
    const n = s.emails.find((e) => e.to === "owner@example.com")!;
    for (const needle of [
      "Amira Test",
      "amira@example.org",
      "Example Health",
      "Tunisia",
      "Healthcare",
      "Over-the-Phone Interpretation (OPI)",
      "50–199 hours",
    ]) {
      expect(n.text).toContain(needle);
      expect(n.html).toContain(needle);
    }
    expect(n.replyTo).toBe("amira@example.org");
  });

  it("stores empty optional fields as null and records consent", async () => {
    const s = setup();
    await processQuote({ ...valid, country: "", monthly_hours: "", requirements: "" }, s.deps);
    expect(s.inserted[0]).toMatchObject({
      country: null,
      monthly_hours: null,
      requirements: null,
      privacy_version: "v1",
      consent_at: "2026-11-17T10:00:00.000Z",
      ip_hash: "hash:203.0.113.9",
      email_status: "pending",
    });
  });

  it("keeps the lead and flags it when the owner notification fails", async () => {
    const s = setup({
      sendEmail: async (m) => {
        if (m.to === "owner@example.com")
          throw new Error("Resend responded 403: domain not verified");
      },
    });
    const r = await processQuote(valid, s.deps);
    expect(r).toEqual({ ok: true, id: "row-1", notified: false, confirmationSent: true });
    expect(s.inserted).toHaveLength(1);
    expect(s.updates[0]).toMatchObject({ email_status: "failed", notified_at: null });
    expect(s.updates[0]?.email_error).toContain("domain not verified");
    expect(s.logs).toContain("notify_failed");
  });

  it("still succeeds if both emails fail", async () => {
    const s = setup({
      sendEmail: async () => {
        throw new Error("down");
      },
    });
    const r = await processQuote(valid, s.deps);
    expect(r).toMatchObject({ ok: true, notified: false, confirmationSent: false });
    expect(s.updates[0]).toMatchObject({ email_status: "failed", confirmation_status: "failed" });
  });

  it("does not fail the request if recording the email status fails", async () => {
    const s = setup({
      updateStatus: async () => {
        throw new Error("db blip");
      },
    });
    const r = await processQuote(valid, s.deps);
    expect(r).toMatchObject({ ok: true, id: "row-1" });
    expect(s.logs).toContain("status_update_failed");
  });

  it("reports failure and sends nothing when the database insert fails", async () => {
    const s = setup({
      insert: async () => {
        throw new Error("db down");
      },
    });
    const r = await processQuote(valid, s.deps);
    expect(r).toMatchObject({ ok: false, code: "save_failed" });
    expect(s.emails).toHaveLength(0);
  });

  it("rejects invalid input on the server with field errors and saves nothing", async () => {
    const s = setup();
    const r = await processQuote({ ...valid, email: "nope", consent: false }, s.deps);
    expect(r).toMatchObject({ ok: false, code: "invalid" });
    if (!r.ok)
      expect(Object.keys(r.fieldErrors ?? {})).toEqual(
        expect.arrayContaining(["email", "consent"]),
      );
    expect(s.inserted).toHaveLength(0);
    expect(s.emails).toHaveLength(0);
  });

  it("silently discards honeypot submissions without saving or emailing", async () => {
    const s = setup();
    const r = await processQuote({ ...valid, extra_details: "http://spam.example" }, s.deps);
    expect(r).toMatchObject({ ok: true, id: null });
    expect(s.inserted).toHaveLength(0);
    expect(s.emails).toHaveLength(0);
    expect(s.logs).toContain("spam_honeypot");
  });

  it("rejects submissions made implausibly fast", async () => {
    const s = setup();
    const r = await processQuote({ ...valid, elapsed_ms: 200 }, s.deps);
    expect(r).toMatchObject({ ok: false, code: "too_fast" });
    const r2 = await processQuote({ ...valid, elapsed_ms: undefined }, s.deps);
    expect(r2).toMatchObject({ ok: false, code: "too_fast" });
    expect(s.inserted).toHaveLength(0);
  });

  it("rate-limits repeat submissions from one network address", async () => {
    const s = setup({ countSince: async (_since, hash) => (hash ? PER_IP_LIMIT : 0) });
    const r = await processQuote(valid, s.deps);
    expect(r).toMatchObject({ ok: false, code: "rate_limited" });
    expect(s.inserted).toHaveLength(0);
  });

  it("applies a global daily ceiling", async () => {
    const s = setup({ countSince: async (_since, hash) => (hash ? 0 : GLOBAL_DAILY_LIMIT) });
    expect(await processQuote(valid, s.deps)).toMatchObject({ ok: false, code: "rate_limited" });
  });

  it("allows submissions just under the limits", async () => {
    const s = setup({
      countSince: async (_s, hash) => (hash ? PER_IP_LIMIT - 1 : GLOBAL_DAILY_LIMIT - 1),
    });
    expect(await processQuote(valid, s.deps)).toMatchObject({ ok: true });
  });

  it("fails open if the rate-limit lookup itself errors, so leads are not lost", async () => {
    const s = setup({
      countSince: async () => {
        throw new Error("count failed");
      },
    });
    expect(await processQuote(valid, s.deps)).toMatchObject({ ok: true, id: "row-1" });
    expect(s.logs).toContain("rate_check_failed");
  });

  it("still applies the global check when the client address is unknown", async () => {
    const s = setup({ ip: null, countSince: async (_s, hash) => (hash ? 0 : GLOBAL_DAILY_LIMIT) });
    expect(await processQuote(valid, s.deps)).toMatchObject({ ok: false, code: "rate_limited" });
  });
});
