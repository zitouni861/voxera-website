import { createFileRoute } from "@tanstack/react-router";
import { seo } from "@/lib/seo";
import { PageHero } from "@/components/site/PageHero";
import { CtaBand } from "@/components/site/Layout";

export const Route = createFileRoute("/services")({
  head: () =>
    seo({
      title: "Services: Phone and Video Interpreting | Voxera",
      description:
        "Over-the-phone (OPI) and video remote (VRI) Arabic-English interpreting for organisations that need accurate, confidential communication.",
      path: "/services",
    }),
  component: Page,
});

const items = [
  {
    id: "opi",
    t: "Over-the-Phone Interpretation (OPI)",
    d: "Telephone interpreting connects English-speaking professionals with Arabic-speaking individuals for clear, accurate conversations across healthcare, insurance and public services. Ideal for enquiries, follow-ups and time-sensitive calls.",
  },
  {
    id: "vri",
    t: "Video Remote Interpretation (VRI)",
    d: "Video interpreting adds visual communication when it is useful, including consultations, appointments and other interactions where seeing participants can help understanding.",
  },
];

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Our services"
        title="Remote interpreting, in the format that fits."
        intro="Telephone and video interpreting that brings an Arabic-English interpreter into the conversation—wherever the people involved are."
      />
      <section className="mx-auto grid max-w-6xl gap-6 px-6 py-20 md:grid-cols-2">
        {items.map((it) => (
          <div
            key={it.id}
            id={it.id}
            className="scroll-mt-24 rounded-xl border border-border bg-card p-8"
          >
            <h2 className="text-2xl">{it.t}</h2>
            <p className="mt-3 text-muted-foreground">{it.d}</p>
          </div>
        ))}
      </section>
      <CtaBand />
    </>
  );
}
