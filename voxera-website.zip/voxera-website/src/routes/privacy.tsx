import { createFileRoute } from "@tanstack/react-router";
import { PageHero } from "@/components/site/PageHero";
import { seo } from "@/lib/seo";
import { CONTACT_EMAIL, PRIVACY_VERSION } from "@/lib/site";

export const Route = createFileRoute("/privacy")({
  head: () =>
    seo({
      title: "Privacy Policy | Voxera",
      description:
        "How Voxera collects, uses, stores and protects the information you send through its enquiry form, and how to ask for access or deletion.",
      path: "/privacy",
    }),
  component: Privacy,
});

const h2 = "mt-12 text-2xl";
const p = "mt-3 leading-relaxed text-muted-foreground";
const ul = "mt-3 list-disc space-y-2 pl-6 leading-relaxed text-muted-foreground";

function Privacy() {
  return (
    <>
      <PageHero
        eyebrow="Legal"
        title="Privacy Policy"
        intro={`How Voxera handles the information you send us. Last updated ${PRIVACY_VERSION}.`}
      />
      <article className="mx-auto max-w-3xl px-6 pb-20 pt-4">
        <h2 className={h2}>Who we are</h2>
        <p className={p}>
          Voxera provides Arabic-English remote interpreting by telephone and video. This policy
          covers this website and the enquiry form on it. You can contact us about anything in this
          policy at{" "}
          <a className="font-semibold text-foreground underline" href={`mailto:${CONTACT_EMAIL}`}>
            {CONTACT_EMAIL}
          </a>
          .
        </p>

        <h2 className={h2}>What we collect</h2>
        <p className={p}>When you submit the enquiry form we collect what you type into it:</p>
        <ul className={ul}>
          <li>Your name, business email address and company name.</li>
          <li>
            Optionally: job title, country, estimated monthly interpreting hours, your current
            requirements and any additional information.
          </li>
          <li>The industry and the service you select.</li>
        </ul>
        <p className={p}>
          We also record the date and time of your submission, the version of this policy you agreed
          to, and a one-way scrambled (hashed) version of your network address. We use that
          scrambled value only to limit spam and cannot turn it back into your address.
        </p>
        <p className={p}>
          Please do not put patient details, account numbers or other confidential personal
          information in the form.
        </p>

        <h2 className={h2}>Why we use it</h2>
        <ul className={ul}>
          <li>To read and respond to your enquiry and, where relevant, prepare a quote.</li>
          <li>To send you an email confirming that we received your enquiry.</li>
          <li>To keep a record of enquiries we have received.</li>
          <li>To protect the form from spam and abuse.</li>
        </ul>

        <h2 className={h2}>Where it is stored and who handles it</h2>
        <p className={p}>
          We use a small number of service providers to run this website. They process information
          on our behalf:
        </p>
        <ul className={ul}>
          <li>
            <strong className="text-foreground">Supabase</strong> hosts the database where enquiries
            are saved.
          </li>
          <li>
            <strong className="text-foreground">Resend</strong> delivers the notification and
            confirmation emails.
          </li>
          <li>
            <strong className="text-foreground">Cloudflare</strong> delivers this website and may
            process technical data such as IP addresses to do so securely.
          </li>
          <li>
            <strong className="text-foreground">Google Fonts</strong> supplies this site&rsquo;s
            typefaces, so your browser contacts Google&rsquo;s servers when a page loads.
          </li>
        </ul>
        <p className={p}>
          These providers may process data in countries other than your own. Access to enquiries on
          our side is limited to people at Voxera who need it to respond. We may also disclose
          information where the law requires it.
        </p>

        <h2 className={h2}>How long we keep it</h2>
        <p className={p}>
          We keep enquiries for as long as we need them to respond and to maintain reasonable
          business records, and then delete them. You can ask us to delete your enquiry sooner.
        </p>

        <h2 className={h2}>Your choices and rights</h2>
        <p className={p}>
          You can email us at{" "}
          <a className="font-semibold text-foreground underline" href={`mailto:${CONTACT_EMAIL}`}>
            {CONTACT_EMAIL}
          </a>{" "}
          to ask:
        </p>
        <ul className={ul}>
          <li>what information we hold about you, and for a copy of it;</li>
          <li>for incorrect information to be corrected;</li>
          <li>for your information to be deleted;</li>
          <li>for us to stop using your information to contact you.</li>
        </ul>
        <p className={p}>
          We may need to confirm that the request comes from the email address used in the enquiry
          before we act on it. Depending on where you live, you may have further rights under local
          law.
        </p>

        <h2 className={h2}>Cookies and tracking</h2>
        <p className={p}>
          This website does not use advertising or analytics cookies and does not track you across
          other sites. Our hosting provider may set essential security cookies where needed to
          protect the site.
        </p>

        <h2 className={h2}>Changes to this policy</h2>
        <p className={p}>
          If we change how we handle information, we will update this page and the date above.
        </p>
      </article>
    </>
  );
}
