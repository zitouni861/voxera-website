import { createFileRoute } from "@tanstack/react-router";
import { seo } from "@/lib/seo";
import { PageHero } from "@/components/site/PageHero";
import { CtaBand } from "@/components/site/Layout";

export const Route = createFileRoute("/industries")({
  head: () =>
    seo({
      title: "Industries: Healthcare, Insurance and Public Services | Voxera",
      description:
        "Arabic-English interpreting for healthcare, insurance, public services and language service providers.",
      path: "/industries",
    }),
  component: Page,
});

const items = [
  {
    id: "healthcare",
    t: "Healthcare",
    d: "Support patient consultations, appointments and other healthcare interactions with clear, accurate interpreting.",
  },
  {
    id: "insurance",
    t: "Insurance",
    d: "Make claims, enquiries and policy conversations clearer for Arabic-speaking customers.",
  },
  {
    id: "public-services",
    t: "Public services",
    d: "Help people access clear communication with public organisations and the services they rely on.",
  },
  {
    id: "lsp",
    t: "Language service providers",
    d: "Add remote Arabic-English interpreting capacity through a specialist partner.",
  },
];

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Who we support"
        title="Built around real-world conversations."
        intro="Arabic-English interpreting support for organisations serving people across different settings."
      />
      <section className="mx-auto grid max-w-6xl gap-6 px-6 py-20 md:grid-cols-2">
        {items.map((it) => (
          <div
            key={it.id}
            id={it.id}
            className="scroll-mt-24 rounded-xl border border-border bg-card p-8"
          >
            <h2 className="text-2xl">{it.t}</h2>
            <p className="mt-3 text-muted-foreground">{it.d}</p>
          </div>
        ))}
      </section>
      <CtaBand />
    </>
  );
}
