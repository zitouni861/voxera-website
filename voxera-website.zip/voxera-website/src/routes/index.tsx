import { createFileRoute, Link } from "@tanstack/react-router";
import { seo } from "@/lib/seo";
import hero from "@/assets/hero-consultation.jpg";
import { CtaBand } from "@/components/site/Layout";

export const Route = createFileRoute("/")({
  head: () =>
    seo({
      title: "Voxera — Arabic-English Remote Interpreting",
      description:
        "Professional Arabic-English interpreting by telephone and video for healthcare, insurance and public services. Accurate, impartial and confidential.",
      path: "/",
      ogTitle: "Voxera — Clear communication without language barriers",
    }),
  component: Index,
});

const services = [
  {
    n: "01",
    t: "Over-the-Phone Interpretation",
    d: "Telephone interpreting connects English-speaking professionals with Arabic-speaking individuals for clear, accurate conversations across healthcare, insurance and public services.",
    h: "opi",
  },
  {
    n: "02",
    t: "Video Remote Interpretation",
    d: "Video interpreting adds visual communication when it is useful, including consultations, appointments and other interactions where seeing participants can help.",
    h: "vri",
  },
];
const industries = [
  {
    t: "Healthcare",
    d: "Support patient consultations and other healthcare interactions.",
    h: "healthcare",
  },
  { t: "Insurance", d: "Make claims, enquiries and policy conversations clearer.", h: "insurance" },
  {
    t: "Public services",
    d: "Help people access clear communication with public organisations.",
    h: "public-services",
  },
  {
    t: "Language service providers",
    d: "Add remote Arabic-English interpreting capacity through a specialist partner.",
    h: "lsp",
  },
];
const steps = [
  {
    t: "Share the requirement",
    d: "Tell us about your organisation, language pair, service format and expected interpreting needs.",
  },
  {
    t: "Agree the right format",
    d: "Discuss whether telephone or video interpreting best fits the setting and conversation.",
  },
  {
    t: "Connect remotely",
    d: "Bring an Arabic-English interpreter into the conversation by phone or video, as arranged.",
  },
];

function Index() {
  return (
    <>
      <section className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-6 py-16 md:grid-cols-2 md:py-24">
        <div>
          <p className="eyebrow">Arabic ↔ English · Remote interpreting</p>
          <h1 className="mt-5 text-[min(3rem,calc((100vw_-_3.5rem)/7.7))] leading-[1.05] sm:text-5xl md:text-6xl">
            Clear Communication. <em className="text-primary">Without Language Barriers.</em>
          </h1>
          <p className="mt-6 max-w-lg text-lg text-muted-foreground">
            Professional Arabic-English interpreting services through telephone and video, helping
            organisations connect with the people they serve.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/contact"
              className="rounded-md bg-primary px-6 py-3 font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Request a Quote →
            </Link>
            <Link
              to="/services"
              className="rounded-md border border-input px-6 py-3 font-semibold hover:bg-secondary"
            >
              Explore Our Services
            </Link>
          </div>
          <div className="mt-8 flex gap-6 text-sm text-muted-foreground">
            <span>● Over-the-Phone Interpretation</span>
            <span>● Video Remote Interpretation</span>
          </div>
        </div>
        <div className="relative">
          <img
            src={hero}
            alt="A clinician and patient communicating with a remote interpreter by video"
            width={1280}
            height={1024}
            className="rounded-xl object-cover shadow-2xl"
          />
          <div className="absolute -bottom-6 -left-6 flex items-center gap-3 rounded-lg bg-card p-4 shadow-xl">
            <span className="font-display text-2xl text-primary">ع↔A</span>
            <div>
              <p className="font-semibold">Arabic ↔ English</p>
              <p className="text-xs text-muted-foreground">Professional remote interpreting</p>
            </div>
          </div>
        </div>
      </section>

      <section className="bg-secondary">
        <div className="mx-auto max-w-4xl px-6 py-20 text-center">
          <p className="eyebrow">A specialist interpreting partner</p>
          <h2 className="mt-4 text-3xl md:text-5xl">
            Every conversation deserves to be understood.
          </h2>
          <p className="mt-6 text-lg text-muted-foreground">
            Voxera helps organisations communicate with Arabic-speaking individuals through
            professional remote interpreting. With telephone and video options, teams can access
            language support in the format that fits the conversation—without needing an interpreter
            in the room.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <p className="eyebrow">Our interpreting services</p>
        <h2 className="mt-4 max-w-2xl text-3xl md:text-5xl">
          Two ways to connect. One clear conversation.
        </h2>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Choose the remote format that suits the setting, the people involved and the nature of the
          discussion.
        </p>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {services.map((s) => (
            <div key={s.n} className="rounded-xl border border-border bg-card p-8">
              <span className="font-display text-4xl text-accent">{s.n}</span>
              <h3 className="mt-4 text-2xl">{s.t}</h3>
              <p className="mt-3 text-muted-foreground">{s.d}</p>
              <Link
                to="/services"
                hash={s.h}
                className="mt-6 inline-block font-semibold text-primary"
              >
                Explore {s.h.toUpperCase()} →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-ink text-ink-foreground">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-accent">
            Who we support
          </p>
          <h2 className="mt-4 text-3xl md:text-5xl">Built around real-world conversations.</h2>
          <div className="mt-12 grid gap-px overflow-hidden rounded-xl bg-ink-foreground/15 sm:grid-cols-2 lg:grid-cols-4">
            {industries.map((i) => (
              <Link
                key={i.t}
                to="/industries"
                hash={i.h}
                className="bg-ink p-6 hover:bg-ink-foreground/5"
              >
                <h3 className="text-xl">{i.t}</h3>
                <p className="mt-2 text-sm opacity-70">{i.d}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-10 px-6 py-20 md:grid-cols-2">
        <div>
          <p className="eyebrow">Why Voxera</p>
          <h2 className="mt-4 text-3xl md:text-5xl">Professionalism at every point of contact.</h2>
        </div>
        <div>
          <p className="text-lg text-muted-foreground">
            Interpreting calls for accuracy, impartiality and care. Voxera's approach centres on
            professional conduct, confidential handling, dependable remote delivery and continuous
            improvement—so organisations can focus on the people in the conversation.
          </p>
          <Link to="/why-voxera" className="mt-6 inline-block font-semibold text-primary">
            Our professional approach →
          </Link>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-6xl px-6 py-20">
          <p className="eyebrow">How it works</p>
          <h2 className="mt-4 text-3xl md:text-5xl">Language support, made straightforward.</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {steps.map((s, i) => (
              <div key={s.t} className="border-t-2 border-primary pt-6">
                <span className="font-display text-3xl text-accent">0{i + 1}</span>
                <h3 className="mt-3 text-xl">{s.t}</h3>
                <p className="mt-2 text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      <CtaBand />
    </>
  );
}
