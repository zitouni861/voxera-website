import { Link, createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { PageHero } from "@/components/site/PageHero";
import { submitQuote } from "@/lib/quote.functions";
import { INDUSTRIES, MONTHLY_HOURS, SERVICES, quoteSchema } from "@/lib/quote-schema";
import { seo } from "@/lib/seo";
import { CONTACT_EMAIL } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  head: () =>
    seo({
      title: "Request a Quote | Voxera",
      description:
        "Tell us about your Arabic-English remote interpreting needs. Share your organisation, service and volume, and the Voxera team will respond to your enquiry.",
      path: "/contact",
    }),
  component: Contact,
});

const field =
  "mt-1.5 w-full rounded-md border border-input bg-card px-3 py-2.5 text-sm outline-none focus:border-ring focus:ring-2 focus:ring-ring/30";
const label = "text-sm font-semibold";
const opt = <span className="ml-1 font-normal text-muted-foreground">Optional</span>;

function Contact() {
  const send = useServerFn(submitQuote);
  const [status, setStatus] = useState<"idle" | "sending" | "done">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [confirmedTo, setConfirmedTo] = useState("");
  const startedAt = useRef(0);
  useEffect(() => {
    startedAt.current = Date.now();
  }, []);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setFormError("");
    const fd = new FormData(e.currentTarget);
    const str = (k: string) => String(fd.get(k) ?? "");
    const parsed = quoteSchema.safeParse({
      full_name: str("full_name"),
      email: str("email"),
      company: str("company"),
      job_title: str("job_title"),
      country: str("country"),
      industry: str("industry"),
      service: str("service"),
      monthly_hours: str("monthly_hours"),
      requirements: str("requirements"),
      additional_info: str("additional_info"),
      consent: fd.get("consent") === "on",
      extra_details: str("extra_details"),
      elapsed_ms: startedAt.current ? Date.now() - startedAt.current : 0,
    });
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      for (const i of parsed.error.issues) errs[String(i.path[0])] ??= i.message;
      setErrors(errs);
      return;
    }
    setErrors({});
    setStatus("sending");
    try {
      const res = await send({ data: parsed.data });
      if (res.ok) {
        setConfirmedTo(res.confirmationSent ? parsed.data.email : "");
        setStatus("done");
      } else {
        setStatus("idle");
        setFormError(res.message);
        if (res.fieldErrors) setErrors(res.fieldErrors);
      }
    } catch {
      setStatus("idle");
      setFormError(
        `We couldn't send your enquiry. Please try again, or email us at ${CONTACT_EMAIL}.`,
      );
    }
  }

  const err = (k: string) =>
    errors[k] ? (
      <p id={`${k}-error`} role="alert" className="mt-1 text-xs text-destructive">
        {errors[k]}
      </p>
    ) : null;
  const invalid = (k: string) =>
    errors[k] ? { "aria-invalid": true, "aria-describedby": `${k}-error` } : {};

  return (
    <>
      <PageHero
        eyebrow="Contact · Request a Quote"
        title="Let's understand your interpreting needs."
        intro="Share a few details about your organisation and the Arabic-English remote interpreting support you are looking for."
      />
      <section className="mx-auto max-w-3xl px-6 py-16">
        {status === "done" ? (
          <div role="status" className="rounded-xl border border-border bg-card p-10 text-center">
            <h2 className="text-3xl">Thank you — enquiry received.</h2>
            <p className="mt-3 text-muted-foreground">
              The Voxera team will review your requirements and be in touch.
            </p>
            {confirmedTo && (
              <p className="mt-2 text-sm text-muted-foreground">
                We have emailed a confirmation to {confirmedTo}.
              </p>
            )}
          </div>
        ) : (
          <form
            onSubmit={onSubmit}
            noValidate
            className="relative grid gap-5 rounded-xl border border-border bg-card p-6 sm:grid-cols-2 sm:p-8"
          >
            <p className="text-sm text-muted-foreground sm:col-span-2">
              Please do not include patient details, account numbers or other confidential personal
              information. We use the details you give only to respond to your enquiry; see our{" "}
              <Link to="/privacy" className="font-semibold underline">
                Privacy Policy
              </Link>
              .
            </p>
            <div>
              <label className={label} htmlFor="full_name">
                Full name *
              </label>
              <input
                id="full_name"
                name="full_name"
                autoComplete="name"
                className={field}
                maxLength={120}
                {...invalid("full_name")}
              />
              {err("full_name")}
            </div>
            <div>
              <label className={label} htmlFor="email">
                Business email *
              </label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                className={field}
                maxLength={255}
                {...invalid("email")}
              />
              {err("email")}
            </div>
            <div>
              <label className={label} htmlFor="company">
                Company name *
              </label>
              <input
                id="company"
                name="company"
                autoComplete="organization"
                className={field}
                maxLength={160}
                {...invalid("company")}
              />
              {err("company")}
            </div>
            <div>
              <label className={label} htmlFor="job_title">
                Job title{opt}
              </label>
              <input
                id="job_title"
                name="job_title"
                autoComplete="organization-title"
                className={field}
                maxLength={120}
              />
            </div>
            <div>
              <label className={label} htmlFor="country">
                Country{opt}
              </label>
              <input
                id="country"
                name="country"
                autoComplete="country-name"
                className={field}
                maxLength={80}
              />
            </div>
            <div>
              <label className={label} htmlFor="industry">
                Industry *
              </label>
              <select
                id="industry"
                name="industry"
                className={field}
                defaultValue=""
                {...invalid("industry")}
              >
                <option value="" disabled>
                  Select an industry
                </option>
                {INDUSTRIES.map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
              {err("industry")}
            </div>
            <div>
              <label className={label} htmlFor="service">
                Service required *
              </label>
              <select
                id="service"
                name="service"
                className={field}
                defaultValue=""
                {...invalid("service")}
              >
                <option value="" disabled>
                  Select a service
                </option>
                {SERVICES.map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
              {err("service")}
            </div>
            <div>
              <span className={label}>Language pair</span>
              <p className={`${field} bg-muted text-muted-foreground`}>Arabic ↔ English</p>
            </div>
            <div className="sm:col-span-2">
              <label className={label} htmlFor="monthly_hours">
                Estimated monthly interpreting hours{opt}
              </label>
              <select id="monthly_hours" name="monthly_hours" className={field} defaultValue="">
                <option value="">Not yet known</option>
                {MONTHLY_HOURS.map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className={label} htmlFor="requirements">
                Current interpreting requirements{opt}
              </label>
              <textarea
                id="requirements"
                name="requirements"
                rows={4}
                maxLength={2000}
                className={field}
              />
            </div>
            <div className="sm:col-span-2">
              <label className={label} htmlFor="additional_info">
                Additional information{opt}
              </label>
              <textarea
                id="additional_info"
                name="additional_info"
                rows={3}
                maxLength={2000}
                className={field}
              />
            </div>
            {/* Spam trap: invisible to people, tempting to bots. Anything typed here is discarded server-side. */}
            <div
              aria-hidden="true"
              className="absolute -left-[9999px] top-auto h-px w-px overflow-hidden"
            >
              <label htmlFor="extra_details">Leave this field empty</label>
              <input
                id="extra_details"
                name="extra_details"
                type="text"
                tabIndex={-1}
                autoComplete="off"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="flex items-start gap-3 text-sm">
                <input
                  type="checkbox"
                  id="consent"
                  name="consent"
                  className="mt-1 h-4 w-4 shrink-0 accent-primary"
                  {...invalid("consent")}
                />
                <span>
                  I have read the{" "}
                  <Link
                    to="/privacy"
                    target="_blank"
                    rel="noopener"
                    className="font-semibold underline"
                  >
                    Privacy Policy
                  </Link>{" "}
                  and agree that Voxera may use the details above to respond to my enquiry. *
                </span>
              </label>
              {err("consent")}
            </div>
            {formError && (
              <p role="alert" className="text-sm text-destructive sm:col-span-2">
                {formError}
              </p>
            )}
            <button
              type="submit"
              disabled={status === "sending"}
              className="rounded-md bg-primary px-6 py-3 font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-60 sm:col-span-2 sm:justify-self-start"
            >
              {status === "sending" ? "Sending…" : "Submit Enquiry →"}
            </button>
          </form>
        )}
      </section>
    </>
  );
}
