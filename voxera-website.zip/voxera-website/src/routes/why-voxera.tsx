import { createFileRoute } from "@tanstack/react-router";
import { seo } from "@/lib/seo";
import { PageHero } from "@/components/site/PageHero";
import { CtaBand } from "@/components/site/Layout";

export const Route = createFileRoute("/why-voxera")({
  head: () =>
    seo({
      title: "Why Voxera: Accuracy, Impartiality and Confidentiality",
      description:
        "Accuracy, impartiality, confidentiality and dependable remote delivery: what to expect when you work with Voxera for Arabic-English interpreting.",
      path: "/why-voxera",
    }),
  component: Page,
});

const items = [
  {
    id: "conduct",
    t: "Professional conduct",
    d: "Interpreters act with accuracy and impartiality, conveying meaning faithfully without adding or omitting.",
  },
  {
    id: "confidential",
    t: "Confidential handling",
    d: "Conversations are treated with discretion and care at every step.",
  },
  {
    id: "delivery",
    t: "Dependable remote delivery",
    d: "Telephone and video formats that connect the right people without needing an interpreter in the room.",
  },
  {
    id: "improvement",
    t: "Continuous improvement",
    d: "An approach that keeps refining quality, consistency and the experience of every conversation.",
  },
];

function Page() {
  return (
    <>
      <PageHero
        eyebrow="Why Voxera"
        title="Professionalism at every point of contact."
        intro="Interpreting calls for accuracy, impartiality and care—so organisations can focus on the people in the conversation."
      />
      <section className="mx-auto grid max-w-6xl gap-6 px-6 py-20 md:grid-cols-2">
        {items.map((it) => (
          <div
            key={it.id}
            id={it.id}
            className="scroll-mt-24 rounded-xl border border-border bg-card p-8"
          >
            <h2 className="text-2xl">{it.t}</h2>
            <p className="mt-3 text-muted-foreground">{it.d}</p>
          </div>
        ))}
      </section>
      <CtaBand />
    </>
  );
}
