export function PageHero({
  eyebrow,
  title,
  intro,
}: {
  eyebrow: string;
  title: string;
  intro: string;
}) {
  return (
    <section className="border-b border-border">
      <div className="mx-auto max-w-4xl px-6 py-20">
        <p className="eyebrow">{eyebrow}</p>
        <h1 className="mt-4 text-4xl leading-tight md:text-6xl">{title}</h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">{intro}</p>
      </div>
    </section>
  );
}
