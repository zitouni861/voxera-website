import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";

const nav = [
  { to: "/services", label: "Services" },
  { to: "/industries", label: "Industries" },
  { to: "/why-voxera", label: "Why Voxera" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  // Close the mobile menu whenever the page changes, and on Escape.
  useEffect(() => setOpen(false), [pathname]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
        <Link to="/" className="font-display text-2xl font-semibold text-foreground">
          Voxera<span className="text-accent">.</span>
        </Link>
        <nav aria-label="Main" className="flex items-center gap-2 text-sm sm:gap-6">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="hidden text-muted-foreground hover:text-foreground sm:inline"
              activeProps={{ className: "text-foreground font-semibold" }}
            >
              {n.label}
            </Link>
          ))}
          <Link
            to="/contact"
            className="rounded-md bg-primary px-3 py-2 font-semibold text-primary-foreground hover:bg-primary/90 sm:px-4"
          >
            Request a Quote
          </Link>
          <button
            type="button"
            className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-border text-foreground hover:bg-muted sm:hidden"
            aria-expanded={open}
            aria-controls="mobile-menu"
            aria-label={open ? "Close menu" : "Open menu"}
            onClick={() => setOpen((v) => !v)}
          >
            <svg
              width="20"
              height="20"
              viewBox="0 0 20 20"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              aria-hidden="true"
            >
              {open ? <path d="M4 4l12 12M16 4L4 16" /> : <path d="M3 5h14M3 10h14M3 15h14" />}
            </svg>
          </button>
        </nav>
      </div>
      {open && (
        <div id="mobile-menu" className="border-t border-border bg-background sm:hidden">
          <ul className="mx-auto max-w-6xl px-4 py-2">
            {nav.map((n) => (
              <li key={n.to}>
                <Link
                  to={n.to}
                  className="block rounded-md px-2 py-3 text-base text-muted-foreground hover:text-foreground"
                  activeProps={{ className: "text-foreground font-semibold" }}
                >
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-6xl gap-8 px-6 py-12 sm:grid-cols-3">
        <div>
          <p className="font-display text-2xl">
            Voxera<span className="text-accent">.</span>
          </p>
          <p className="mt-2 text-sm opacity-70">
            Professional Arabic ↔ English remote interpreting by phone and video.
          </p>
        </div>
        <nav aria-label="Footer" className="flex flex-col gap-2 text-sm opacity-80">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="hover:opacity-100">
              {n.label}
            </Link>
          ))}
          <Link to="/contact">Contact</Link>
          <Link to="/privacy">Privacy Policy</Link>
        </nav>
        <p className="text-sm opacity-60 sm:text-right">© {new Date().getFullYear()} Voxera</p>
      </div>
    </footer>
  );
}

export function CtaBand() {
  return (
    <section className="bg-primary text-primary-foreground">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-6 py-16 md:flex-row md:items-center">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] opacity-70">
            Start a conversation
          </p>
          <h2 className="mt-2 text-3xl md:text-4xl">
            Looking for Arabic-English interpreting support?
          </h2>
          <p className="mt-2 opacity-80">
            Share your requirements and the Voxera team will understand what your organisation
            needs.
          </p>
        </div>
        <Link
          to="/contact"
          className="rounded-md bg-accent px-6 py-3 font-semibold text-accent-foreground hover:bg-accent/90"
        >
          Request a Quote →
        </Link>
      </div>
    </section>
  );
}
