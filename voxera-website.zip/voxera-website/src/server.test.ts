import { describe, expect, it } from "vitest";
import { withSecurityHeaders } from "./server";

describe("withSecurityHeaders", () => {
  it("adds baseline headers and preserves status and body", async () => {
    const res = withSecurityHeaders(
      new Response("hello", { status: 404, headers: { "content-type": "text/plain" } }),
    );
    expect(res.status).toBe(404);
    expect(await res.text()).toBe("hello");
    expect(res.headers.get("x-content-type-options")).toBe("nosniff");
    expect(res.headers.get("x-frame-options")).toBe("DENY");
    expect(res.headers.get("referrer-policy")).toBe("strict-origin-when-cross-origin");
    expect(res.headers.get("content-type")).toBe("text/plain");
  });
  it("never sets content-encoding (the edge compresses responses)", () => {
    expect(withSecurityHeaders(new Response("x")).headers.has("content-encoding")).toBe(false);
  });
  it("does not override a header the app already set", () => {
    const res = withSecurityHeaders(
      new Response("x", { headers: { "x-frame-options": "SAMEORIGIN" } }),
    );
    expect(res.headers.get("x-frame-options")).toBe("SAMEORIGIN");
  });
});
