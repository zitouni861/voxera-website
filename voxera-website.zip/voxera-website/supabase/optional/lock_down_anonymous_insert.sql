-- Voxera: OPTIONAL hardening. DO NOT run this until the live contact form has been tested end to end.
--
-- The website saves enquiries from its own server using the service-role key, which bypasses
-- row-level security. The public "anyone can insert" rule is therefore no longer needed, and it
-- lets anyone with the public key write rows directly, skipping the website's spam checks.
-- Removing it leaves row-level security ON with no public rules, i.e. public access is denied.
--
-- To undo, re-create the policy and re-grant INSERT using drizzle/migrations/0000_migration.sql.

DROP POLICY IF EXISTS "Anyone can submit a quote request" ON public.quote_requests;
REVOKE INSERT ON public.quote_requests FROM anon, authenticated;
