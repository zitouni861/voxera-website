-- Voxera: enquiry tracking columns.
-- ADDITIVE ONLY: no data is changed or deleted, and existing rows are left as they are.
-- Safe to run more than once. Run this BEFORE deploying the new website code.

ALTER TABLE public.quote_requests
  ADD COLUMN IF NOT EXISTS consent_at          timestamptz,
  ADD COLUMN IF NOT EXISTS privacy_version     text,
  ADD COLUMN IF NOT EXISTS ip_hash             text,   -- salted one-way hash, used only for rate limiting
  ADD COLUMN IF NOT EXISTS email_status        text,   -- pending | sent | failed (owner notification)
  ADD COLUMN IF NOT EXISTS email_error         text,
  ADD COLUMN IF NOT EXISTS notified_at         timestamptz,
  ADD COLUMN IF NOT EXISTS confirmation_status text;   -- sent | failed (email to the enquirer)

-- Applies to new rows only; older rows keep NULL so they are not mislabelled.
ALTER TABLE public.quote_requests ALTER COLUMN email_status SET DEFAULT 'pending';

CREATE INDEX IF NOT EXISTS quote_requests_created_at_idx ON public.quote_requests (created_at DESC);
CREATE INDEX IF NOT EXISTS quote_requests_ip_hash_created_idx ON public.quote_requests (ip_hash, created_at DESC);
